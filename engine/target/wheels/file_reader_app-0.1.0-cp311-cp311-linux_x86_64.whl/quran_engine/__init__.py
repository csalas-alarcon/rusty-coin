from .quran_engine import *

__doc__ = quran_engine.__doc__
if hasattr(quran_engine, "__all__"):
    __all__ = quran_engine.__all__